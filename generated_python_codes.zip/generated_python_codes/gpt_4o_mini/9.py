def binary_search_recursive(arr, target, left, right):
    if left > right:
        return -1  # Target not found
    mid = left + (right - left) // 2
    if arr[mid] == target:
        return mid
    elif arr[mid] > target:
        return binary_search_recursive(arr, target, left, mid - 1)
    else:
        return binary_search_recursive(arr, target, mid + 1, right)

def binary_search_iterative(arr, target):
    left, right = 0, len(arr) - 1
    while left <= right:
        mid = left + (right - left) // 2
        if arr[mid] == target:
            return mid
        elif arr[mid] > target:
            right = mid - 1
        else:
            left = mid + 1
    return -1  # Target not found

def main():
    arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    target = 5
    
    result_recursive = binary_search_recursive(arr, target, 0, len(arr) - 1)
    result_iterative = binary_search_iterative(arr, target)

    print(f"Recursive: Target {target} found at index: {result_recursive}")
    print(f"Iterative: Target {target} found at index: {result_iterative}")

    target_not_found = 11
    result_recursive_not_found = binary_search_recursive(arr, target_not_found, 0, len(arr) - 1)
    result_iterative_not_found = binary_search_iterative(arr, target_not_found)

    print(f"Recursive: Target {target_not_found} found at index: {result_recursive_not_found}")
    print(f"Iterative: Target {target_not_found} found at index: {result_iterative_not_found}")

if __name__ == "__main__":
    main()
