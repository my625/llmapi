Sure, here is a clean Python solution for implementing a singly linked list with insert, delete, and display functions:

class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class LinkedList:
    def __init__(self):
        self.head = None

    def insert(self, data):
        """Insert a new node at the beginning of the linked list"""
        new_node = Node(data)
        new_node.next = self.head
        self.head = new_node

    def delete(self, data):
        """Delete the first node with the given data"""
        current_node = self.head
        prev_node = None

        while current_node is not None:
            if current_node.data == data:
                if prev_node is None:
                    self.head = current_node.next
                else:
                    prev_node.next = current_node.next
                return
            prev_node = current_node
            current_node = current_node.next

    def display(self):
        """Display all the nodes in the linked list"""
        current_node = self.head

        while current_node is not None:
            print(current_node.data, end=' ')
            current_node = current_node.next
        print()

if __name__ == '__main__':
    # Example input/output handling
    llist = LinkedList()
    llist.insert(1)
    llist.insert(2)
    llist.insert(3)
    llist.display()  # Output: 3 2 1
    llist.delete(2)
    llist.display()  # Output: 3 1
