Sure, here is a clean Python solution for the programming assignment:

def check_balanced_parentheses(input_string):
    """
    Checks if the input string has balanced parentheses/brackets using stack.
    :param input_string: input string to check
    :return: True if balanced, False otherwise
    """
    stack = []
    for char in input_string:
        if char in '([{':
            stack.append(char)
        elif char in ')]}':
            if not stack:
                return False
            elif char == ')' and stack[-1] == '(':
                stack.pop()
            elif char == ']' and stack[-1] == '[':
                stack.pop()
            elif char == '}' and stack[-1] == '{':
                stack.pop()
            else:
                return False
    return not stack

if __name__ == '__main__':
    input_string = input('Enter a string to check for balanced parentheses/brackets: ')
    if check_balanced_parentheses(input_string):
        print('The input string is balanced.')
    else:
        print('The input string is not balanced.')
