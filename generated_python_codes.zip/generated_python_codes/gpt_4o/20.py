from collections import OrderedDict

class LRUCache:
    def __init__(self, capacity: int):
        self.capacity = capacity
        self.cache = OrderedDict()

    def get(self, key: int) -> int:
        if key not in self.cache:
            return -1
        # Move the accessed item to the end to show it was recently used
        self.cache.move_to_end(key)
        return self.cache[key]

    def put(self, key: int, value: int) -> None:
        if key in self.cache:
            # Update the value and move it to the end
            self.cache.move_to_end(key)
        self.cache[key] = value
        # If over capacity, remove the oldest item
        if len(self.cache) > self.capacity:
            self.cache.popitem(last=False)

def main():
    cache = LRUCache(2)
    print(cache.get(1))  # Output: -1
    cache.put(1, 1)
    cache.put(2, 2)
    print(cache.get(1))  # Output: 1
    cache.put(3, 3)
    print(cache.get(2))  # Output: -1
    cache.put(4, 4)
    print(cache.get(1))  # Output: -1
    print(cache.get(3))  # Output: 3
    print(cache.get(4))  # Output: 4

if __name__ == "__main__":
    main()
