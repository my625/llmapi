def first_non_repeating_character(s):
    # Dictionary to store the frequency of each character
    char_count = {}
    
    # First pass: Count the occurrences of each character
    for char in s:
        if char in char_count:
            char_count[char] += 1
        else:
            char_count[char] = 1
    
    # Second pass: Find the first non-repeating character
    for char in s:
        if char_count[char] == 1:
            return char
    
    return None  # Return None if no non-repeating character is found

def main():
    # Example input strings
    examples = [
        "swiss",
        "programming",
        "aabbcc",
        "abcabcde",
        "xxyyzz"
    ]
    
    # Process each example and print the result
    for i, example in enumerate(examples):
        result = first_non_repeating_character(example)
        print(f"Example {i+1}: '{example}' -> {result}")

if __name__ == "__main__":
    main()
