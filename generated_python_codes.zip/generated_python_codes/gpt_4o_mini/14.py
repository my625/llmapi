class Node:
    def __init__(self, data):
        self.data = data
        self.next = None


class SinglyLinkedList:
    def __init__(self):
        self.head = None

    def insert(self, data):
        new_node = Node(data)
        if not self.head:
            self.head = new_node
            return
        current = self.head
        while current.next:
            current = current.next
        current.next = new_node

    def delete(self, data):
        if not self.head:
            return
        if self.head.data == data:
            self.head = self.head.next
            return
        current = self.head
        while current.next:
            if current.next.data == data:
                current.next = current.next.next
                return
            current = current.next

    def display(self):
        current = self.head
        elements = []
        while current:
            elements.append(current.data)
            current = current.next
        return elements


def main():
    sll = SinglyLinkedList()
    while True:
        choice = input("Choose (1: Insert, 2: Delete, 3: Display, 4: Exit): ")
        if choice == '1':
            data = input("Enter data to insert: ")
            sll.insert(data)
        elif choice == '2':
            data = input("Enter data to delete: ")
            sll.delete(data)
        elif choice == '3':
            print("List contents:", sll.display())
        elif choice == '4':
            break
        else:
            print("Invalid choice. Try again.")


