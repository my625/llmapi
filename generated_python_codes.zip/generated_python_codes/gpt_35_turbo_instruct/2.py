Sure thing! Here's a solution that meets all the requirements:

def isPalindrome(s):
    """Check if a string is a palindrome after removing non-alphanumeric characters."""
    s = ''.join(c for c in s if c.isalnum())
    return s == s[::-1]

def main():
    """Example input/output handling."""
    s = input('Enter a string: ')
    if isPalindrome(s):
        print('The input string is a palindrome after removing non-alphanumeric characters.')
    else:
        print('The input string is not a palindrome after removing non-alphanumeric characters.')

if __name__ == '__main__':
    main()

# Example input/output:
# Enter a string: A man, a plan, a canal: Panama!
# The input string is a palindrome after removing non-alphanumeric characters.
