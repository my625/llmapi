import sys
from typing import List, Union

Number = Union[int, float]

def tokenize(expr: str) -> List[str]:
    expr = expr.strip()
    if not expr:
        return []
    return expr.split() if any(c.isspace() for c in expr) else list(expr)

def parse_number(tok: str) -> Number:
    if "." in tok:
        return float(tok)
    return int(tok)

def apply_op(op: str, a: Number, b: Number) -> Number:
    if op == "+": return a + b
    if op == "-": return a - b
    if op == "*": return a * b
    if op == "/":
        if b == 0:
            raise ZeroDivisionError("division by zero")
        return int(a / b) if isinstance(a, int) and isinstance(b, int) else a / b
    if op == "%": return a % b
    if op == "^": return a ** b
    raise ValueError(f"unknown operator: {op}")

def eval_postfix(expr: str) -> Number:
    stack: List[Number] = []
    for tok in tokenize(expr):
        if tok in {"+", "-", "*", "/", "%", "^"} and not (tok == "-" and len(tok) > 1):
            if len(stack) < 2:
                raise ValueError("invalid postfix expression")
            b = stack.pop()
            a = stack.pop()
            stack.append(apply_op(tok, a, b))
        else:
            stack.append(parse_number(tok))
    if len(stack) != 1:
        raise ValueError("invalid postfix expression")
    return stack[0]

def main() -> None:
    data = sys.stdin.read()
    if data.strip():
        print(eval_postfix(data))
    else:
        expr = "5 1 2 + 4 * + 3 -"
        print(expr)
        print(eval_postfix(expr))

if __name__ == "__main__":
    main()
