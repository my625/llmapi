# Function to find all anagrams of pattern in text
def find_anagrams(pattern, text):
    # Convert pattern and text to lowercase
    pattern = pattern.lower()
    text = text.lower()
    # Initialize empty list to store anagrams
    anagrams = []
    # Loop through each character in text
    for i in range(len(text)):
        # Check if pattern and text substring of length len(pattern) starting at index i are anagrams
        if sorted(pattern) == sorted(text[i:i + len(pattern)]):
            # Append anagram to list
            anagrams.append(text[i:i + len(pattern)])
    return anagrams
# Example input/output handling
if __name__ == '__main__':
    pattern = 'act'
    text = 'cat tac act'
    print(find_anagrams(pattern, text))  # Output: ['cat', 'tac']
