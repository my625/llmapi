import sys


def to_int(s, default=None):
    try:
        return int(s)
    except Exception:
        return default


def get_n():
    if len(sys.argv) > 1:
        n = to_int(sys.argv[1])
        if n is not None:
            return n
    data = sys.stdin.read().strip().split()
    if data:
        n = to_int(data[0])
        if n is not None:
            return n
    return 3  # example fallback


def hanoi(n, src, aux, dst, out):
    if n <= 0:
        return
    hanoi(n - 1, src, dst, aux, out)
    out.append(f"{src} {dst}")
    hanoi(n - 1, aux, src, dst, out)


def main():
    n = get_n()
    if n < 0:
        return
    sys.setrecursionlimit(max(1000, n + 50))

    out = []
    hanoi(n, 1, 2, 3, out)
    sys.stdout.write("\n".join(out))


if __name__ == "__main__":
    main()
