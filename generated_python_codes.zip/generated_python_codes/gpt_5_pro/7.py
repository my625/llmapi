import sys


def parse_int(text, default=10):
    text = (text or "").strip()
    if not text:
        return default
    try:
        return int(text)
    except ValueError:
        return default


def fib(n, memo):
    if n in memo:
        return memo[n]
    memo[n] = fib(n - 1, memo) + fib(n - 2, memo)
    return memo[n]


def fib_sequence(n):
    if n <= 0:
        return []
    memo = {0: 0, 1: 1}
    return [fib(i, memo) for i in range(n)]


def format_sequence(seq):
    return " ".join(str(x) for x in seq)


def main():
    data = sys.stdin.read()
    n = parse_int(data, default=10)

    if n < 0:
        sys.stdout.write("n must be non-negative\n")
        return

    sys.setrecursionlimit(max(1000, n + 50))
    seq = fib_sequence(n)

    # Example output: for n=5 -> 0 1 1 2 3
    sys.stdout.write(format_sequence(seq) + ("\n" if seq or n == 0 else ""))


if __name__ == "__main__":
    main()
