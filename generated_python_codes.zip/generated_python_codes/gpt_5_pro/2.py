import sys


def is_palindrome(text: str) -> bool:
    i, j = 0, len(text) - 1
    while i < j:
        while i < j and not text[i].isalnum():
            i += 1
        while i < j and not text[j].isalnum():
            j -= 1
        if i >= j:
            break
        if text[i].lower() != text[j].lower():
            return False
        i += 1
        j -= 1
    return True


def read_text_from_stdin() -> str | None:
    data = sys.stdin.read()
    if not data:
        return None
    return data.rstrip("\n")


def run_examples() -> None:
    samples = [
        "A man, a plan, a canal: Panama",
        "race a car",
        "No 'x' in Nixon",
        "",
        ".,,,",
    ]
    for s in samples:
        sys.stdout.write(f"Input:  {s!r}\n")
        sys.stdout.write(f"Output: {is_palindrome(s)}\n\n")


def main() -> None:
    text = read_text_from_stdin()
    if text is None:
        run_examples()
    else:
        sys.stdout.write(str(is_palindrome(text)))


if __name__ == "__main__":
    main()
