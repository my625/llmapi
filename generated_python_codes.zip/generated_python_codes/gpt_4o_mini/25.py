def count_distinct_substrings(s):
    n = len(s)
    substrings = set()
    
    # Generate all possible substrings
    for i in range(n):
        for j in range(i + 1, n + 1):
            substrings.add(s[i:j])
    
    return len(substrings)

def main():
    # Example input
    input_string = input("Enter a string: ")
    result = count_distinct_substrings(input_string)
    
    # Output the result
    print(f"Number of distinct substrings: {result}")

if __name__ == "__main__":
    main()
