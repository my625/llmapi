def count_distinct_substrings(s: str) -> int:
    substrings = set()
    n = len(s)
    
    # Generate all possible substrings
    for i in range(n):
        for j in range(i + 1, n + 1):
            substring = s[i:j]
            substrings.add(substring)
    
    return len(substrings)

def main():
    # Example input
    example_string = "abc"
    # Output distinct substrings count
    result = count_distinct_substrings(example_string)
    print(f"Distinct substrings count for '{example_string}': {result}")

    # Another example
    example_string = "aaa"
    result = count_distinct_substrings(example_string)
    print(f"Distinct substrings count for '{example_string}': {result}")

if __name__ == "__main__":
    main()
