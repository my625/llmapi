import sys
from typing import List, Tuple

def build_graph(n: int, edges: List[Tuple[int, int]], undirected: bool = True) -> List[List[int]]:
    g = [[] for _ in range(n + 1)]
    for u, v in edges:
        if 1 <= u <= n and 1 <= v <= n:
            g[u].append(v)
            if undirected:
                g[v].append(u)
    return g

def dfs_traversal(g: List[List[int]], start: int) -> List[int]:
    n = len(g) - 1
    if start < 1 or start > n:
        return []
    visited = [False] * (n + 1)
    order, stack = [], [start]
    while stack:
        v = stack.pop()
        if visited[v]:
            continue
        visited[v] = True
        order.append
