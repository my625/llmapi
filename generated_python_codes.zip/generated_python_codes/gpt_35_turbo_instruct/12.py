Sure, here is a solution that follows all the rules:

def evaluate_postfix(expression):
    """Evaluates a postfix expression using a stack."""
    stack = []
    for element in expression.split():
        if element in '+-*/':
            b = stack.pop()
            a = stack.pop()
            stack.append(eval(str(a) + element + str(b)))
        else:
            stack.append(float(element))
    return stack.pop()

if __name__ == '__main__':
    expression = input('Enter postfix expression: ')
    print(evaluate_postfix(expression))
