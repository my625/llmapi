def quick_sort(arr):
    if len(arr) <= 1:
        return arr
    pivot = arr[len(arr) // 2]
    left = [x for x in arr if x < pivot]
    middle = [x for x in arr if x == pivot]
    right = [x for x in arr if x > pivot]
    return quick_sort(left) + middle + quick_sort(right)

def main():
    # Example input for testing the quick_sort function
    input_array = [34, 7, 23, 32, 5, 62]
    print("Original array:", input_array)
    
    sorted_array = quick_sort(input_array)
    print("Sorted array:", sorted_array)

if __name__ == "__main__":
    main()
