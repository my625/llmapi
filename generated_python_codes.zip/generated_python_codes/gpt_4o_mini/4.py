def reverse_words(sentence):
    # Split the sentence into words
    words = sentence.split()
    
    # Reverse the order of words
    reversed_words = words[::-1]
    
    # Join the reversed words back into a single string
    reversed_sentence = ' '.join(reversed_words)
    
    return reversed_sentence

def main():
    # Example input/output handling
    example_input = "Hello world this is a test"
    print("Original Sentence:", example_input)
    
    # Call the function to reverse words
    output = reverse_words(example_input)
    
    print("Reversed Words:", output)

    # Additional test cases
    test_cases = [
        "Python is fun",
        "Keep it simple",
        "Data structures and algorithms",
        "Reverse these words",
        "SingleWord"
    ]
    
    for case in test_cases:
        print(f"Original: {case} => Reversed: {reverse_words(case)}")

if __name__ == "__main__":
    main()
