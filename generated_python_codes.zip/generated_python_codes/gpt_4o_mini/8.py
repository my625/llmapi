def tower_of_hanoi(n, source, target, auxiliary, moves):
    if n == 1:
        moves.append((source, target))
        return
    tower_of_hanoi(n - 1, source, auxiliary, target, moves)
    moves.append((source, target))
    tower_of_hanoi(n - 1, auxiliary, target, source, moves)

def main():
    try:
        n = int(input("Enter the number of disks: "))
        if n < 1:
            print("Number of disks must be a positive integer.")
            return
    except ValueError:
        print("Invalid input. Please enter a positive integer.")
        return

    moves = []
    tower_of_hanoi(n, 'A', 'C', 'B', moves)

    print(f"Total moves required: {len(moves)}")
    for move in moves:
        print(f"Move disk from {move[0]} to {move[1]}")

if __name__ == "__main__":
    main()
