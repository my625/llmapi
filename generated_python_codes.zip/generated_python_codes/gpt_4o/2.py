def is_palindrome(s: str) -> bool:
    # Filter non-alphanumeric characters and convert to lowercase
    filtered_chars = [char.lower() for char in s if char.isalnum()]
    # Compare filtered list with its reverse
    return filtered_chars == filtered_chars[::-1]

def main():
    # Example test cases
    test_cases = [
        "A man, a plan, a canal: Panama",
        "No lemon, no melon",
        "Hello, World!",
        "Was it a car or a cat I saw?",
        "Madam, in Eden, I'm Adam",
        "This is not a palindrome"
    ]

    # Check each test case and print the result
    for i, test in enumerate(test_cases, 1):
        result = is_palindrome(test)
        print(f"Test case {i}: {result}")

if __name__ == "__main__":
    main()
