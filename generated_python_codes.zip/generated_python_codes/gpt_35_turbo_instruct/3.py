Here is a simple solution for finding the longest palindromic substring in a given string, using Python's built-in functions and methods.

def longest_palindrome(string):
    """
    Finds the longest palindromic substring in a given string.
    """
    longest = ''
    for i in range(len(string)):
        for j in range(len(string), i, -1):
            if string[i:j] == string[i:j][::-1]:
                if len(string[i:j]) > len(longest):
                    longest = string[i:j]
    return longest

def main():
    """
    Handles example input/output for testing.
    """
    string = 'abcbabcba'
    print('Input:', string)
    print('Longest palindromic substring:', longest_palindrome(string))

if __name__ == '__main__':
    main()
