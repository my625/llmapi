class Stack:
    def __init__(self):
        self.items = []

    def push(self, item):
        self.items.append(item)

    def pop(self):
        if not self.is_empty():
            return self.items.pop()
        raise IndexError("pop from empty stack")

    def is_empty(self):
        return len(self.items) == 0

def evaluate_postfix(expression):
    stack = Stack()
    tokens = expression.split()

    for token in tokens:
        if token.isdigit() or (token[0] == '-' and token[1:].isdigit()):
            stack.push(int(token))
        else:
            right_operand = stack.pop()
            left_operand = stack.pop()
            result = None
            if token == '+':
                result = left_operand + right_operand
            elif token == '-':
                result = left_operand - right_operand
            elif token == '*':
                result = left_operand * right_operand
            elif token == '/':
                result = left_operand / right_operand
            else:
                raise ValueError(f"Unknown operator: {token}")
            stack.push(result)

    if stack.is_empty():
        raise ValueError("Invalid postfix expression")
    return stack.pop()

def main():
    expression = "3 4 + 2 * 7 /"
    result = evaluate_postfix(expression)
    print(f"Result of '{expression}' is {result}")

if __name__ == "__main__":
    main()
