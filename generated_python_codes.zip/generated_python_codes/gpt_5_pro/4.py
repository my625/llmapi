import sys


def tokenize(sentence: str):
    tokens = []
    i = 0
    n = len(sentence)
    while i < n:
        j = i
        is_space = sentence[i].isspace()
        while j < n and sentence[j].isspace() == is_space:
            j += 1
        tokens.append((is_space, sentence[i:j]))
        i = j
    return tokens


def reverse_words_preserve_spacing(sentence: str) -> str:
    tokens = tokenize(sentence)
    words = [t for is_space, t in tokens if not is_space]
    words.reverse()
    out = []
    wi = 0
    for is_space, t in tokens:
        if is_space:
            out.append(t)
        else:
            out.append(words[wi])
            wi += 1
    return "".join(out)


def process_text(text: str) -> str:
    lines = text.splitlines(True)  # keep line endings
    out_lines = []
    for line in lines:
        if line.endswith("\n"):
            out_lines.append(reverse_words_preserve_spacing(line[:-1]) + "\n")
        else:
            out_lines.append(reverse_words_preserve_spacing(line))
    return "".join(out_lines)


def main():
    data = sys.stdin.read()
    if not data:
        s = "The quick brown fox jumps over the lazy dog"
        print("Input:", s)
        print("Output:", reverse_words_preserve_spacing(s))
        return
    sys.stdout.write(process_text(data))


if __name__ == "__main__":
    main()
