def recursive_factorial(n):
    if n < 0:
        raise ValueError("Factorial is not defined for negative numbers.")
    if n == 0:
        return 1
    return n * recursive_factorial(n - 1)

def iterative_factorial(n):
    if n < 0:
        raise ValueError("Factorial is not defined for negative numbers.")
    result = 1
    for i in range(2, n + 1):
        result *= i
    return result

def compare_factorial(n):
    rec_result = recursive_factorial(n)
    iter_result = iterative_factorial(n)
    return rec_result == iter_result

def main():
    test_values = [0, 1, 5, 10]
    for value in test_values:
        try:
            rec_fact = recursive_factorial(value)
            iter_fact = iterative_factorial(value)
            comparison = compare_factorial(value)
            print(f"Value: {value}, Recursive: {rec_fact}, Iterative: {iter_fact}, Equal: {comparison}")
        except ValueError as e:
            print(f"Value: {value}, Error: {e}")

if __name__ == "__main__":
    main()
