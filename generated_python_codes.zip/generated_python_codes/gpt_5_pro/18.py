import sys
from collections import Counter

def find_anagram_starts(text: str, pattern: str):
    n, m = len(text), len(pattern)
    if m == 0 or m > n:
        return []
    diff = Counter(pattern)
    nonzero = len(diff)

    def upd(ch, delta):
        nonlocal nonzero
        before = diff.get(ch, 0)
        after = before + delta
        if before == 0 and after != 0:
            nonzero += 1
        elif before != 0 and after == 0:
            nonzero -= 1
        if after == 0:
            diff.pop(ch, None)
        else:
            diff[ch] = after

    for ch in text[:m]:
        upd(ch, -1)

    res = []
    if nonzero == 0:
        res.append(0)

    for i in range(m, n):
        upd(text[i - m], +1)
        upd(text[i], -1)
        if nonzero == 0:
            res.append(i - m + 1)
    return res

def main():
    data = [line.rstrip("\n") for line in sys.stdin.readlines()]
    if len(data) >= 2:
        text, pattern = data[0], data[1]
    else:
        text, pattern = "cbaebabacd", "abc"
    ans = find_anagram_starts(text, pattern)
    sys.stdout.write(" ".join(map(str, ans)) + ("\n" if ans or data else ""))

if __name__ ==
