import sys


class Stack:
    def __init__(self):
        self._data = []

    def push(self, item):
        self._data.append(item)

    def pop(self):
        if self.is_empty():
            raise IndexError("pop from empty stack")
        return self._data.pop()

    def peek(self):
        if self.is_empty():
            raise IndexError("peek from empty stack")
        return self._data[-1]

    def is_empty(self):
        return not self._data


def _parse_value(s):
    try:
        return int(s)
    except ValueError:
        return s


def main():
    stack = Stack()
    lines = sys.stdin.read().splitlines()
    if not lines:
        lines = ["push 10", "push 20", "peek", "pop", "empty", "pop"]

    out = []
    for raw in lines:
        parts = raw.strip().split()
        if not parts:
            continue
        cmd = parts[0].lower()
        try:
            if cmd == "push":
                if len(parts) < 2:
                    out.append("ERROR")
                else:
                    stack.push(_parse_value(" ".join(parts[1:])))
            elif cmd == "pop":
                out.append(str(stack.pop()))
            elif cmd == "peek":
                out.append(str(stack.peek()))
            elif cmd in ("empty", "is_empty"):
                out.append(str(stack.is_empty()))
            else:
                out.append("ERROR")
        except IndexError:
            out.append("EMPTY")

