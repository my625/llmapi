Here's a clean Python solution for the Tower of Hanoi problem:

# Define a function to solve the Tower of Hanoi problem
def hanoi(n, source, auxiliary, target):
    # Base case: when there's only one disk left, move it from source to target
    if n == 1:
        print('Move disk 1 from', source, 'to', target)
        return
    # Recursive case: move n-1 disks from source to auxiliary tower
    hanoi(n - 1, source, target, auxiliary)
    # Move the last disk from source to target
    print('Move disk', n, 'from', source, 'to', target)
    # Move the n-1 disks from auxiliary to target tower
    hanoi(n - 1, auxiliary, source, target)

# Main function to handle input/output
def main():
    n = int(input('Enter the number of disks: '))
    hanoi(n, 'A', 'B', 'C')

if __name__ == '__main__':
    main()

# Example output for n = 3:
# Move disk 1 from A to C
# Move disk 2 from A to B
# Move disk 1 from C to B
# Move disk 3 from A to C
# Move disk 1 from B to A
# Move disk 2 from B to C
# Move disk 1 from A to C
