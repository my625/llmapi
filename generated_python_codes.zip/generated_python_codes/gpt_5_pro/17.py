import sys


def partition(a, lo, hi):
    pivot = a[hi]
    i = lo
    for j in range(lo, hi):
        if a[j] <= pivot:
            a[i], a[j] = a[j], a[i]
            i += 1
    a[i], a[hi] = a[hi], a[i]
    return i


def quicksort(a):
    n = len(a)
    if n < 2:
        return
    stack = [(0, n - 1)]
    while stack:
        lo, hi = stack.pop()
        while lo < hi:
            p = partition(a, lo, hi)
            # Process smaller side first to keep stack small
            if p - lo < hi - p:
                if p + 1 < hi:
                    stack.append((p + 1, hi))
                hi = p - 1
            else:
                if lo < p - 1:
                    stack.append((lo, p - 1))
                lo = p + 1


def parse_input(data):
    if not data:
        return [3, 1, 4, 1, 5, 9, 2, 6]
    if len(data) >= 2 and data[0] == len(data) - 1:
        return data[1:]
    return data


def main():
    data = list(map(int, sys.stdin.buffer.read().split()))
    arr = parse_input(data)
    quicksort(arr)
    sys.stdout.write(" ".join(map(str, arr)) + "\n")


if __name__ == "__main__":
    main()
