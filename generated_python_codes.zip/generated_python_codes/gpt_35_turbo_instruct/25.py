def count_distinct_substrings(string):
    """
    Counts distinct substrings of a string using a set-based method.
    """
    substrings = set()
    for i in range(len(string)):
        for j in range(i + 1, len(string) + 1):
            substrings.add(string[i:j])
    return len(substrings)

if __name__ == '__main__':
    string = 'programming'
    print('Input string:', string)
    print('Number of distinct substrings:', count_distinct_substrings(string))
