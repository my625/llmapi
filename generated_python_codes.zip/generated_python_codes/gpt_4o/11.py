from collections import deque

class Queue:
    def __init__(self):
        self.queue = deque()

    def enqueue(self, item):
        self.queue.append(item)

    def dequeue(self):
        if self.is_empty():
            raise IndexError("Dequeue from empty queue")
        return self.queue.popleft()

    def is_empty(self):
        return len(self.queue) == 0

    def size(self):
        return len(self.queue)

    def peek(self):
        if self.is_empty():
            raise IndexError("Peek from empty queue")
        return self.queue[0]

    def __str__(self):
        return f"Queue({list(self.queue)})"

def main():
    q = Queue()
    
    # Enqueue elements
    q.enqueue(10)
    q.enqueue(20)
    q.enqueue(30)
    
    # Display queue
    print("Initial queue:", q)
    
    # Dequeue elements
    print("Dequeued:", q.dequeue())
    print("Queue after dequeue:", q)
    
    # Peek at the front element
    print("Front element:", q.peek())
    
    # Queue status
    print("Is queue empty?", q.is_empty())
    print("Queue size:", q.size())

if __name__ == "__main__":
    main()
