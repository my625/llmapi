class InfixToPostfixConverter:
    def __init__(self):
        self.precedence = {'+': 1, '-': 1, '*': 2, '/': 2, '^': 3}
        self.associativity = {'+': 'L', '-': 'L', '*': 'L', '/': 'L', '^': 'R'}
        self.output = []
        self.stack = []

    def is_operator(self, token):
        return token in self.precedence

    def precedence_of(self, token):
        return self.precedence.get(token, 0)

    def is_left_associative(self, token):
        return self.associativity.get(token, 'L') == 'L'

    def process_operator(self, token):
        while (self.stack and self.stack[-1] != '(' and
               (self.precedence_of(self.stack[-1]) > self.precedence_of(token) or
                (self.precedence_of(self.stack[-1]) == self.precedence_of(token) and
                 self.is_left_associative(token)))):
            self.output.append(self.stack.pop())
        self.stack.append(token)

    def convert(self, expression):
        tokens = expression.split()
        for token in tokens:
            if token.isalnum():  # Operand
                self.output.append(token)
            elif token == '(':  # Left parenthesis
                self.stack.append(token)
            elif token == ')':  # Right parenthesis
                while self.stack and self.stack[-1] != '(':
                    self.output.append(self.stack.pop())
                self.stack.pop()  # Remove '(' from stack
            elif self.is_operator(token):  # Operator
                self.process_operator(token)
        while self.stack:  # Pop all the operators from the stack
            self.output.append(self.stack.pop())
        return ' '.join(self.output)


def main():
    expression = input("Enter an infix expression (e.g., 'A + B * C'): ")
    converter = InfixToPostfixConverter()
    postfix = converter.convert(expression)
    print("Postfix expression:", postfix)


if __name__ == '__main__':
    main()
