Here is a solution that satisfies all the rules:

import collections

def shortest_path(grid, start, end):
    queue = collections.deque([(start, 0)])
    visited = set()
    while queue:
        curr, distance = queue.popleft()
        if curr == end:
            return distance
        if curr in visited:
            continue
        visited.add(curr)
        for neighbor in get_neighbors(grid, curr):
            queue.append((neighbor, distance + 1))
    return -1

def get_neighbors(grid, curr):
    row, col = curr
    neighbors = []
    if row > 0:
        neighbors.append((row - 1, col))
    if row < len(grid) - 1:
        neighbors.append((row + 1, col))
    if col > 0:
        neighbors.append((row, col - 1))
    if col < len(grid[0]) - 1:
        neighbors.append((row, col + 1))
    return [neighbor for neighbor in neighbors if grid[neighbor[0]][neighbor[1]] == 1]

def main():
    grid = [[1, 1, 1, 1, 1],
            [0, 0, 0, 1, 1],
            [1, 1, 1, 1, 1],
            [1, 0, 0, 0, 1],
            [1, 1, 1, 1, 1]]
    start = (0, 0)
    end = (4, 4)
    print(shortest_path(grid, start, end))

if __name__ == '__main__':
    main()
