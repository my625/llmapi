def is_balanced(expression):
    stack = []
    matching_bracket = {')': '(', '}': '{', ']': '['}
    
    for char in expression:
        if char in matching_bracket.values():  # If it's an opening bracket
            stack.append(char)
        elif char in matching_bracket.keys():  # If it's a closing bracket
            if not stack or stack[-1] != matching_bracket[char]:
                return False
            stack.pop()  # Remove the matched opening bracket
    
    return not stack  # True if stack is empty, False otherwise

def main():
    print("Enter an expression to check for balanced parentheses/brackets:")
    expression = input().strip()
    
    if is_balanced(expression):
        print("The expression is balanced.")
    else:
        print("The expression is not balanced.")

if __name__ == "__main__":
    main()
