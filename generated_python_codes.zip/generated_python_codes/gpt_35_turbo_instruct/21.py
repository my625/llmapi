Sure, I can help you with that. Here's a clean solution for converting infix expressions to postfix expressions in Python:

def infix_to_postfix(expression):
    """Converts infix expression to postfix expression"""
    stack = []
    output = []
    operators = {'+': 1, '-': 1, '*': 2, '/': 2, '^': 3}

    for char in expression:
        if char.isdigit():
            output.append(char)
        elif char == '(':
            stack.append(char)
        elif char == ')':
            while stack and stack[-1] != '(':
                output.append(stack.pop())
            stack.pop()
        else:
            while stack and operators.get(char, 0) <= operators.get(stack[-1], 0):
                output.append(stack.pop())
            stack.append(char)

    while stack:
        output.append(stack.pop())

    return ''.join(output)

def main():
    """Handles input and output"""
    expression = input('Enter an infix expression: ')
    postfix_expression = infix_to_postfix(expression)
    print('Postfix expression:', postfix_expression)

if __name__ == '__main__':
    main()

# Example input/output:
# Enter an infix expression: (2+3)*5
# Postfix expression: 23+5*
