def reverse_sentence_words(sentence):
    # Split the sentence into words
    words = sentence.split()
    # Reverse the list of words
    reversed_words = words[::-1]
    # Join the reversed list of words into a new sentence
    reversed_sentence = ' '.join(reversed_words)
    return reversed_sentence

def main():
    # Example sentence
    example_sentence = "Hello world this is a test"
    # Reverse the words in the sentence
    reversed_sentence = reverse_sentence_words(example_sentence)
    # Print the original and reversed sentences
    print("Original:", example_sentence)
    print("Reversed:", reversed_sentence)

if __name__ == "__main__":
    main()
