import sys
from typing import Optional, List


class ListNode:
    __slots__ = ("val", "next")

    def __init__(self, val: int, next: Optional["ListNode"] = None):
        self.val = val
        self.next = next


def build_list(values: List[int]) -> Optional[ListNode]:
    if not values:
        return None
    head = ListNode(values[0])
    cur = head
    for v in values[1:]:
        cur.next = ListNode(v)
        cur = cur.next
    return head


def attach_cycle(head: Optional[ListNode], pos: int) -> None:
    if head is None or pos < 0:
        return
    nodes = []
    cur = head
    while cur:
        nodes.append(cur)
        if cur.next is None:
            break
        cur = cur.next
    if 0 <= pos < len(nodes):
        nodes[-1].next = nodes[pos]


def has_cycle(head: Optional[ListNode]) -> bool:
    slow = fast = head
    while fast and fast.next:
        slow = slow.next
        fast = fast.next.next
        if slow is fast:
            return True
    return False


def main() -> None:
    data = sys.stdin.read().strip().split()
    if not data:
        n, values, pos = 5, [3, 2, 0, -4, 7], 1
        head = build_list(values)
        attach_cycle(head, pos)
        print(has_cycle(head))
        return

    it = iter(data)
    n = int(next(it, "0"))
    values = [int(next(it)) for _ in range(n)] if n > 0 else []
    pos = int(next(it, "-1"))
