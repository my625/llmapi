def fibonacci(n, memo):
    if n in memo:
        return memo[n]
    if n <= 1:
        return n
    memo[n] = fibonacci(n - 1, memo) + fibonacci(n - 2, memo)
    return memo[n]

def generate_fibonacci_sequence(length):
    if length < 0:
        raise ValueError("Length must be a non-negative integer.")
    memo = {}
    sequence = [fibonacci(i, memo) for i in range(length)]
    return sequence

def main():
    try:
        length = int(input("Enter the length of Fibonacci sequence: "))
        sequence = generate_fibonacci_sequence(length)
        print(f"Fibonacci sequence of length {length}: {sequence}")
    except ValueError as e:
        print(e)

if __name__ == "__main__":
    main()
