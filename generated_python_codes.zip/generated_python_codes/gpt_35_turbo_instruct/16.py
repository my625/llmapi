Sure, here's a clean solution for merge sort implementation in Python:

def merge_sort(arr):
    """Sorts an integer array using merge sort algorithm."""
    if len(arr) <= 1:
        return arr

    mid = len(arr) // 2
    left = arr[:mid]
    right = arr[mid:]

    left = merge_sort(left)
    right = merge_sort(right)

    return merge(left, right)

def merge(left, right):
    """Merges two sorted integer arrays into one."""
    result = []
    i = j = 0

    while i < len(left) and j < len(right):
        if left[i] < right[j]:
            result.append(left[i])
            i += 1
        else:
            result.append(right[j])
            j += 1

    result.extend(left[i:])
    result.extend(right[j:])

    return result

def main():
    """Handles example input/output."""
    arr = [7, 3, 9, 1, 5, 2, 8, 4, 6]
    sorted_arr = merge_sort(arr)
    print(sorted_arr)  # [1, 2, 3, 4, 5, 6, 7, 8, 9]

if __name__ == '__main__':
    main()
