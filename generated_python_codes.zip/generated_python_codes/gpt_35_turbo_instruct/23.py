Here is the code:

def dfs(graph, start):
    visited = []
    stack = [start]
    while stack:
        node = stack.pop()
        if node not in visited:
            visited.append(node)
            for neighbor in graph[node]:
                stack.append(neighbor)
    return visited

# Example input/output handling
if __name__ == '__main__':
    graph = {'A': ['B', 'C'], 'B': ['D'], 'C': ['E'], 'D': ['F'], 'E': ['G'], 'F': ['H'], 'G': [], 'H': []}
    print(dfs(graph, 'A'))  # Output: ['A', 'B', 'D', 'F', 'H', 'C', 'E', 'G']
