import sys
import argparse
from typing import Set


def count_distinct_substrings(s: str) -> int:
    # Set-based method: generate all non-empty substrings and count uniques.
    n = len(s)
    seen: Set[str] = set()
    for i in range(n):
        for j in range(i + 1, n + 1):
            seen.add(s[i:j])
    return len(seen)


def read_input_string(args: argparse.Namespace) -> str:
    if args.string is not None:
        return args.string
    data = sys.stdin.read().splitlines()
    if data:
        return data[0].rstrip("\n
