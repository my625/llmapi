Sure, here's the solution:

import collections

class Queue:
    def __init__(self):
        self.queue = collections.deque()

    def enqueue(self, item):
        self.queue.append(item)

    def dequeue(self):
        return self.queue.popleft()

def main():
    q = Queue()
    q.enqueue(1)
    q.enqueue(2)
    q.enqueue(3)
    print(q.dequeue()) # output: 1
    print(q.dequeue()) # output: 2
    print(q.dequeue()) # output: 3

if __name__ == '__main__':
    main()
