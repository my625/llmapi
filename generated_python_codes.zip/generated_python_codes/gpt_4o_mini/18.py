def find_anagrams(text, pattern):
    from collections import Counter

    pattern_length = len(pattern)
    pattern_count = Counter(pattern)
    result_indices = []

    # Initial window in the text
    window_count = Counter(text[:pattern_length])

    for i in range(len(text) - pattern_length + 1):
        if i > 0:
            # Slide the window: remove the leftmost character and add the new rightmost character
            left_char = text[i - 1]
            right_char = text[i + pattern_length - 1] if i + pattern_length - 1 < len(text) else None
            
            window_count[left_char] -= 1
            if window_count[left_char] == 0:
                del window_count[left_char]
            if right_char:
                window_count[right_char] += 1

        # Compare the window with the pattern count
        if window_count == pattern_count:
            result_indices.append(i)

    return result_indices

def main():
    text = input("Enter the text: ")
    pattern = input("Enter the pattern: ")
    
    indices = find_anagrams(text, pattern)
    
    if indices:
        print("Anagram indices:", indices)
    else:
        print("No anagrams found.")

if __name__ == "__main__":
    main()
