from collections import OrderedDict

class LRUCache:
    def __init__(self, capacity: int):
        self.capacity = capacity
        self.cache = OrderedDict()

    def get(self, key: int) -> int:
        if key not in self.cache:
            return -1  # Key not found
        else:
            self.cache.move_to_end(key)  # Move key to the end to mark it as recently used
            return self.cache[key]

    def put(self, key: int, value: int) -> None:
        if key in self.cache:
            self.cache.move_to_end(key)  # Move key to the end to mark it as recently used
        self.cache[key] = value
        if len(self.cache) > self.capacity:
            self.cache.popitem(last=False)  # Remove the first item (least recently used)

def main():
    cache = LRUCache(2)
    print(cache.put(1, 1))  # Cache is {1=1}
    print(cache.put(2, 2))  # Cache is {1=1, 2=2}
    print(cache.get(1))     # Returns 1
    print(cache.put(3, 3))  # Evicts key 2, Cache is {1=1, 3=3}
    print(cache.get(2))     # Returns -1 (not found)
    print(cache.put(4, 4))  # Evicts key 1, Cache is {3=3, 4=4}
    print(cache.get(1))     # Returns -1 (not found)
    print(cache.get(3))     # Returns 3
    print(cache.get(4))     # Returns 4

if __name__ == "__main__":
    main()
