class Graph:
    def __init__(self):
        self.graph = {}

    def add_edge(self, u, v):
        if u not in self.graph:
            self.graph[u] = []
        if v not in self.graph:
            self.graph[v] = []
        self.graph[u].append(v)
        self.graph[v].append(u)  # For undirected graph

    def dfs(self, start, visited=None):
        if visited is None:
            visited = set()
        visited.add(start)
        result = [start]
        for neighbor in self.graph.get(start, []):
            if neighbor not in visited:
                result.extend(self.dfs(neighbor, visited))
        return result

def main():
    g = Graph()
    
    edges = [
        (0, 1), (0, 2), (1, 3), (1, 4),
        (2, 5), (3, 6), (4, 6), (5, 6)
    ]
    
    for u, v in edges:
        g.add_edge(u, v)

    start_node = 0
    print("DFS Traversal starting from node", start_node, ":")
    dfs_result = g.dfs(start_node)
    print(dfs_result)

if __name__ == "__main__":
    main()
