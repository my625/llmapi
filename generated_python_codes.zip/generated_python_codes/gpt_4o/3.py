def longest_palindrome(s):
    if not s:
        return ""
    
    start, max_len = 0, 1

    def expand_around_center(left, right):
        nonlocal start, max_len
        while left >= 0 and right < len(s) and s[left] == s[right]:
            current_len = right - left + 1
            if current_len > max_len:
                start = left
                max_len = current_len
            left -= 1
            right += 1

    for i in range(len(s)):
        expand_around_center(i, i)       # Odd length palindrome
        expand_around_center(i, i + 1)   # Even length palindrome

    return s[start:start + max_len]

def main():
    example_input = "babad"
    print("Longest palindromic substring of:", example_input)
    print("Result:", longest_palindrome(example_input))

    example_input = "cbbd"
    print("Longest palindromic substring of:", example_input)
    print("Result:", longest_palindrome(example_input))

    example_input = "a"
    print("Longest palindromic substring of:", example_input)
    print("Result:", longest_palindrome(example_input))

    example_input = "ac"
    print("Longest palindromic substring of:", example_input)
    print("Result:", longest_palindrome(example_input))

if __name__ == "__main__":
    main()
