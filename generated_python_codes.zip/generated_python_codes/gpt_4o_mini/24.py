from collections import deque

def is_valid_move(grid, visited, row, col):
    return (0 <= row < len(grid)) and (0 <= col < len(grid[0])) and (grid[row][col] == 0) and not visited[row][col]

def bfs_shortest_path(grid, start, end):
    if not grid or grid[start[0]][start[1]] == 1 or grid[end[0]][end[1]] == 1:
        return -1

    rows, cols = len(grid), len(grid[0])
    visited = [[False] * cols for _ in range(rows)]
    queue = deque([(start, 0)])  # (position, distance)
    visited[start[0]][start[1]] = True

    directions = [(0, 1), (1, 0), (0, -1), (-1, 0)]

    while queue:
        (current_row, current_col), distance = queue.popleft()

        if (current_row, current_col) == end:
            return distance

        for dr, dc in directions:
            new_row, new_col = current_row + dr, current_col + dc
            if is_valid_move(grid, visited, new_row, new_col):
                visited[new_row][new_col] = True
                queue.append(((new_row, new_col), distance + 1))

    return -1

def main():
    grid = [
        [0, 0, 1, 0, 0],
        [0, 0, 1, 0, 0],
        [0, 0, 0, 0, 1],
        [0, 1, 1, 0, 0],
        [0, 0, 0, 0, 0]
    ]
    start = (0, 0)  # Starting position
    end = (4, 4)    # Ending position

    shortest_path_length = bfs_shortest_path(grid, start, end)
    print(f"Shortest path length from {start} to {end}: {shortest_path_length}")

if __name__ == "__main__":
    main()
