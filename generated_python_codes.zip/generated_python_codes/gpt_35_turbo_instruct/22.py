Here is a clean Python solution for implementing BFS traversal on an unweighted graph:

import collections

def bfs(graph, start):
    visited = set()
    queue = collections.deque([start])

    while queue:
        node = queue.popleft()
        if node not in visited:
            visited.add(node)
            print(node)
            queue.extend(graph[node] - visited)

if __name__ == '__main__':
    graph = {
        'A': {'B', 'C'},
        'B': {'A', 'D', 'E'},
        'C': {'A', 'F'},
        'D': {'B'},
        'E': {'B', 'F'},
        'F': {'C', 'E'}
    }

    bfs(graph, 'A')

Output:
A
B
C
D
E
F
