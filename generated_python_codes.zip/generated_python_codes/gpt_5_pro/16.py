import sys


def merge_sort(a):
    n = len(a)
    if n < 2:
        return a

    aux = [0] * n

    def sort(lo, hi):
        if hi - lo <= 1:
            return
        mid = (lo + hi) // 2
        sort(lo, mid)
        sort(mid, hi)
        merge(lo, mid, hi)

    def merge(lo, mid, hi):
        i, j, k = lo, mid, lo
        while i < mid and j < hi:
            if a[i] <= a[j]:
                aux[k] = a[i]
                i += 1
            else:
                aux[k] = a[j]
                j += 1
            k += 1
        while i < mid:
            aux[k] = a[i]
            i += 1
            k += 1
        while j < hi:
            aux[k] = a[j]
            j += 1
            k += 1
        a[lo:hi] = aux[lo:hi
