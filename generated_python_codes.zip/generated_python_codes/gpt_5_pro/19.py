import sys
from typing import Dict, Optional


def first_non_repeating_char(s: str) -> Optional[str]:
    counts: Dict[str, int] = {}
    order = []

    for ch in s:
        if ch in counts:
            counts[ch] += 1
        else:
            counts[ch] = 1
            order.append(ch)

    for ch in order:
        if counts[ch] == 1:
            return ch
    return None


def solve_one(s: str) -> str:
    ch = first_non_repeating_char(s)
    return ch if ch is not None else "-1"


def main() -> None:
    data = sys.stdin.read()
    s = data.rstrip("\n")

    if s == "":
        # Demo mode when no stdin is provided
        examples = ["swiss", "aabbcc", "leetcode", "x", ""]
        for ex in examples:
            sys.stdout.write(f"input: {ex!r}\n")
            sys.stdout.write(f"output: {solve_one(ex)}\n")
        return

    sys.stdout.write(solve_one(s) + "\n")


if __name__ == "__main__":
    main()
