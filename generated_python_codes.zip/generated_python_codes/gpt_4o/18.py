def find_anagrams(s, p):
    from collections import Counter

    # Length of the pattern and the text
    len_p, len_s = len(p), len(s)

    # Result list to store starting indices of anagrams
    result = []

    # Create frequency counter for the pattern
    p_counter = Counter(p)
    # Initialize a counter for the current window in the text
    window_counter = Counter(s[:len_p])

    # Check if the initial window is an anagram
    if window_counter == p_counter:
        result.append(0)

    # Slide the window over the text
    for i in range(len_p, len_s):
        # Add the new character to the window
        window_counter[s[i]] += 1
        # Remove the character that is sliding out of the window
        window_counter[s[i - len_p]] -= 1

        # Remove the count of a character from the window counter if it's zero
        if window_counter[s[i - len_p]] == 0:
            del window_counter[s[i - len_p]]

        # Compare window counter with pattern counter
        if window_counter == p_counter:
            result.append(i - len_p + 1)

    return result

def main():
    text = "cbaebabacd"
    pattern = "abc"
    result = find_anagrams(text, pattern)
    print(f"Anagram indices of '{pattern}' in '{text}': {result}")

if __name__ == "__main__":
    main()
