Sure, here is a solution that meets all the requirements:

def count_frequency(string):
    """Count frequency of each character in a string and return a dictionary"""
    frequency = {}
    for char in string:
        if char in frequency:
            frequency[char] += 1
        else:
            frequency[char] = 1
    return frequency

def main():
    """Main function to handle example input/output"""
    input_string = input("Enter a string: ")
    frequency = count_frequency(input_string)
    print("Frequency of each character in the string:")
    for char in sorted(frequency, key=frequency.get, reverse=True):
        print(char, frequency[char])

if __name__ == '__main__':
    main()

# Example input/output:
# Input: "hello world"
# Output:
# Frequency of each character in the string:
# l 3
# o 2
# h 1
# e 1
# w 1
# r 1
# d 1
#   1
