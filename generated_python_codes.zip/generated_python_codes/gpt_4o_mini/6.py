def recursive_factorial(n):
    if n == 0 or n == 1:
        return 1
    return n * recursive_factorial(n - 1)

def iterative_factorial(n):
    result = 1
    for i in range(2, n + 1):
        result *= i
    return result

def compare_factorials(n):
    recursive_result = recursive_factorial(n)
    iterative_result = iterative_factorial(n)
    
    print(f"Factorial of {n} (Recursive): {recursive_result}")
    print(f"Factorial of {n} (Iterative): {iterative_result}")
    
    if recursive_result == iterative_result:
        print("Both methods give the same result.")
    else:
        print("The methods give different results.")

def main():
    try:
        user_input = int(input("Enter a non-negative integer: "))
        if user_input < 0:
            print("Please enter a non-negative integer.")
            return
        
        compare_factorials(user_input)
        
    except ValueError:
        print("Invalid input. Please enter an integer.")

if __name__ == "__main__":
    main()
