import sys
import time


def fact_recursive(n: int) -> int:
    if n < 2:
        return 1
    return n * fact_recursive(n - 1)


def fact_iterative(n: int) -> int:
    res = 1
    for k
