def fibonacci(n, memo={}):
    # Check if the value is already computed
    if n in memo:
        return memo[n]
    
    # Base cases
    if n <= 0:
        return 0
    elif n == 1:
        return 1
    
    # Recursive case with memoization
    memo[n] = fibonacci(n - 1, memo) + fibonacci(n - 2, memo)
    return memo[n]

def main():
    while True:
        try:
            user_input = input("Enter a non-negative integer (or 'exit' to quit): ")
            if user_input.lower() == 'exit':
                print("Exiting the program.")
                break
            
            n = int(user_input)
            if n < 0:
                print("Please enter a non-negative integer.")
                continue
            
            result = fibonacci(n)
            print(f"The {n}th Fibonacci number is: {result}")
        
        except ValueError:
            print("Invalid input. Please enter a non-negative integer.")

if __name__ == "__main__":
    main()
