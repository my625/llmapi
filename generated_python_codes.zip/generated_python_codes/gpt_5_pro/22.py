import sys
from collections import deque

def bfs(n, adj, start):
    if not (0 <= start < n):
        return []
    vis = [False] * n
    q = deque([start])
    vis[start] = True
    order = []
    while q:
        u = q.popleft()
        order.append(u)
        for v in adj[u]:
            if not vis[v]:
                vis[v] = True
                q.append(v)
    return order

def parse_graph(data):
    t = data.split()
    if len(t) < 2:
        return None
    nums = list(map(int, t))
    n, m = nums[0], nums[1]
    need = 2 + 2 * m
    if len(nums) < need:
        return None
    edge_vals = nums[2:need]
    start = nums[need] if len(nums) > need else 0
    verts = edge_vals + [start]
    one_index = bool(verts) and min(verts) >= 1 and max(verts) <= n
    if one_index:
        edge_vals = [x - 1 for x in edge_vals]
        start -= 1
    adj = [[] for _ in range(n)]
    for i in range(0, len(edge_vals), 2):
        u, v = edge_vals[i], edge_vals[i + 1]
        if 0 <= u < n and 0 <= v < n:
            adj[u].append(v)
            adj[v].append(u)  # undirected
    for lst in adj:
        lst.sort()
    return n, adj, start
