def is_palindrome(s: str) -> bool:
    # Remove non-alphanumeric characters and convert to lowercase
    cleaned = ''.join(char.lower() for char in s if char.isalnum())
    # Check if the cleaned string is equal to its reverse
    return cleaned == cleaned[::-1]

def main():
    # Example input/output handling
    test_cases = [
        "A man, a plan, a canal: Panama",
        "race a car",
        "No 'x' in Nixon",
        "Hello, World!",
        "Was it a car or a cat I saw?"
    ]
    
    for case in test_cases:
        result = is_palindrome(case)
        print(f"Input: {case}\nIs palindrome: {result}\n")

if __name__ == "__main__":
    main()
