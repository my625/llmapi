import sys


class Node:
    __slots__ = ("data", "next")

    def __init__(self, data, nxt=None):
        self.data = data
        self.next = nxt


class SinglyLinkedList:
    def __init__(self):
        self.head = None

    def insert(self, value):
        n = Node(value)
        if not self.head:
            self.head = n
            return
        cur = self.head
        while cur.next:
            cur = cur.next
        cur.next = n

    def delete(self, value):
        prev, cur = None, self.head
        while cur:
            if cur.data == value:
                if prev:
                    prev.next = cur.next
                else:
                    self.head = cur.next
                return True
            prev, cur = cur, cur.next
        return False

    def display(self):
        if not self.head:
            return "Empty"
        out, cur = [], self.head
        while cur:
            out.append(str(cur.data))
            cur = cur.next
        return " ".join(out)


def run_commands(lines):
    sll, out = SinglyLinkedList(), []
    for line in lines:
        parts = line.strip().split()
        if not parts:
            continue
        cmd = parts[0].lower()
        if cmd in ("insert", "i") and len(parts) >= 2:
            sll.insert(parts[1])
        elif cmd in ("delete", "d") and len(parts) >= 2:
            sll.delete(parts[1])
        elif cmd in ("display", "print", "p"):
            out.append(sll.display())
