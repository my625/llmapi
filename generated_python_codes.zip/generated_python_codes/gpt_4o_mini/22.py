from collections import deque

class Graph:
    def __init__(self):
        self.adjacency_list = {}

    def add_edge(self, u, v):
        if u not in self.adjacency_list:
            self.adjacency_list[u] = []
        if v not in self.adjacency_list:
            self.adjacency_list[v] = []
        self.adjacency_list[u].append(v)
        self.adjacency_list[v].append(u)

    def bfs(self, start):
        visited = set()
        queue = deque([start])
        bfs_order = []

        while queue:
            vertex = queue.popleft()
            if vertex not in visited:
                visited.add(vertex)
                bfs_order.append(vertex)
                queue.extend(neighbor for neighbor in self.adjacency_list.get(vertex, []) if neighbor not in visited)

        return bfs_order

def main():
    g = Graph()
    edges = [
        (1, 2), (1, 3), (2, 4), (2, 5),
        (3, 6), (3, 7), (4, 8), (5, 9)
    ]

    for u, v in edges:
        g.add_edge(u, v)

    start_vertex = 1
    print("BFS Traversal starting from vertex", start_vertex)
    bfs_result = g.bfs(start_vertex)
    print(bfs_result)

if __name__ == "__main__":
    main()
