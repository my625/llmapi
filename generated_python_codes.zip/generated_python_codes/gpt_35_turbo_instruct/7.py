Sure, I can help you with that! Here's a clean Python solution for generating Fibonacci sequence using recursion with memoization:

def fibonacci(n):
    """ Returns the n-th Fibonacci number using recursion with memoization. """
    if n == 0:
        return 0
    elif n == 1:
        return 1
    else:
        return fibonacci(n-1) + fibonacci(n-2)

def main():
    """ Main function to handle example input/output. """
    n = int(input("Enter a number: "))
    print("Fibonacci sequence up to", n, "terms:")
    for i in range(n):
        print(fibonacci(i))

if __name__ == '__main__':
    main()

# Example input/output:
# Enter a number: 8
# Fibonacci sequence up to 8 terms:
# 0 1 1 2 3 5 8 13
