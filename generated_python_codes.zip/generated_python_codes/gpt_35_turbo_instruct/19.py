Here's a solution for the assignment:

def find_first_non_repeating_char(string):
    """Finds the first non-repeating character in a string."""
    char_count = {} # dictionary to store character counts
    for char in string:
        if char in char_count:
            char_count[char] += 1
        else:
            char_count[char] = 1
    for char in string:
        if char_count[char] == 1:
            return char
    return None # if no non-repeating character is found

def main():
    """Handles example input/output."""
    input_str = "aabbccddeeff"
    print("Input string: {}".format(input_str))
    first_non_repeating_char = find_first_non_repeating_char(input_str)
    if first_non_repeating_char:
        print("First non-repeating character: {}".format(first_non_repeating_char))
    else:
        print("No non-repeating character found.")

if __name__ == '__main__':
    main()
