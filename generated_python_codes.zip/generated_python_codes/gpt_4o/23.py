from collections import defaultdict

class Graph:
    def __init__(self):
        self.graph = defaultdict(list)

    def add_edge(self, u, v):
        self.graph[u].append(v)

    def dfs(self, start):
        visited = set()
        traversal = []
        self._dfs_util(start, visited, traversal)
        return traversal

    def _dfs_util(self, v, visited, traversal):
        visited.add(v)
        traversal.append(v)
        for neighbor in self.graph[v]:
            if neighbor not in visited:
                self._dfs_util(neighbor, visited, traversal)

def main():
    g = Graph()
    g.add_edge(0, 1)
    g.add_edge(0, 2)
    g.add_edge(1, 2)
    g.add_edge(2, 0)
    g.add_edge(2, 3)
    g.add_edge(3, 3)
    
    start_node = 2
    print("DFS Traversal from node", start_node, ":", g.dfs(start_node))

if __name__ == "__main__":
    main()
