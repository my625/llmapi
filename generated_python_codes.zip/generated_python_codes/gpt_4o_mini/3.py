def longest_palindromic_substring(s: str) -> str:
    if len(s) == 0:
        return ""

    start, end = 0, 0

    def expand_around_center(left: int, right: int) -> int:
        while left >= 0 and right < len(s) and s[left] == s[right]:
            left -= 1
            right += 1
        return right - left - 1

    for i in range(len(s)):
        len1 = expand_around_center(i, i)  # Odd length palindrome
        len2 = expand_around_center(i, i + 1)  # Even length palindrome
        max_len = max(len1, len2)

        if max_len > end - start:
            start = i - (max_len - 1) // 2
            end = i + max_len // 2

    return s[start:end + 1]

def main():
    input_string = input("Enter a string: ")
    result = longest_palindromic_substring(input_string)
    print("Longest palindromic substring:", result)

if __name__ == "__main__":
    main()
