import sys


def lcs(a: str, b: str):
    n, m = len(a), len(b)
    dp = [[0] * (m + 1) for _ in range(n + 1)]

    for i in range(n):
        ai = a[i]
        cur = dp[i + 1]
        prev = dp[i]
        for j in range(m):
            if ai == b[j]:
                cur[j + 1] = prev[j] + 1
            else:
                left = cur[j]
                up = prev[j + 1]
                cur[j + 1] = left if left >= up else up

    i, j = n, m
    out = []
    while i > 0 and j > 0:
        if a[i - 1] == b[j - 1]:
            out.append(a[i - 1])
            i -= 1
            j -= 1
        elif dp[i - 1][j] >= dp[i][j - 1]:
            i -= 1
        else:
            j -= 1

    return dp[n][m], "".join(reversed(out))


def main():
    data = [line.rstrip("\n") for line in sys.stdin]
    if len(data) >= 2:
        s1, s2 = data[0], data[1]
    else:
        s1, s2 = "AGGTAB", "GXTXAYB"  # example
    length, subseq = lcs(s1, s2)
    sys.stdout.write(f"{length}\n{subseq}\n")


if __name__ == "__main__":
    main()
