# Function to determine precedence of operators
def precedence(op):
    if op in ('+', '-'):
        return 1
    if op in ('*', '/'):
        return 2
    if op == '^':
        return 3
    return 0

# Function to perform infix to postfix conversion
def infix_to_postfix(expression):
    stack = []  # Stack to store operators
    output = []  # List for resulting postfix expression
    for char in expression:
        if char.isalnum():  # If alphanumeric character, add to output
            output.append(char)
        elif char == '(':  # If '(', push to stack
            stack.append(char)
        elif char == ')':  # If ')', pop until '(' is found
            while stack and stack[-1] != '(':
                output.append(stack.pop())
            stack.pop()
        else:  # Operator encountered
            while stack and precedence(stack[-1]) >= precedence(char):
                output.append(stack.pop())
            stack.append(char)
    # Pop all remaining operators in the stack
    while stack:
        output.append(stack.pop())
    return ''.join(output)

def main():
    expression = "a+b*(c^d-e)^(f+g*h)-i"
    result = infix_to_postfix(expression)
    print(f"Infix: {expression}")
    print(f"Postfix: {result}")

if __name__ == "__main__":
    main()
