Here is a clean Python solution for the LCS problem using dynamic programming:

def lcs(str1, str2):
    """Function to calculate the LCS of two strings"""
    m = len(str1)
    n = len(str2)
    lcs_matrix = [[(0) for x in range(n + 1)] for x in range(m + 1)]
    for i in range(m + 1):
        for j in range(n + 1):
            if i == 0 or j == 0:
                lcs_matrix[i][j] = 0
            elif str1[i - 1] == str2[j - 1]:
                lcs_matrix[i][j] = lcs_matrix[i - 1][j - 1] + 1
            else:
                lcs_matrix[i][j] = max(lcs_matrix[i - 1][j], lcs_matrix[i][j - 1])
    return lcs_matrix[m][n]

if __name__ == '__main__':
    str1 = 'ABCDGH'
    str2 = 'AEDFHR'
    print('The LCS of {} and {} is {}'.format(str1, str2, lcs(str1, str2)))

Output:
The LCS of ABCDGH and AEDFHR is 3
