class Stack:
    def __init__(self):
        self.items = []

    def push(self, item):
        """Add an item to the top of the stack."""
        self.items.append(item)

    def pop(self):
        """Remove and return the top item of the stack. Raise IndexError if the stack is empty."""
        if self.is_empty():
            raise IndexError("pop from empty stack")
        return self.items.pop()

    def peek(self):
        """Return the top item of the stack without removing it. Raise IndexError if the stack is empty."""
        if self.is_empty():
            raise IndexError("peek from empty stack")
        return self.items[-1]

    def is_empty(self):
        """Return True if the stack is empty, otherwise False."""
        return len(self.items) == 0

    def size(self):
        """Return the number of items in the stack."""
        return len(self.items)

def main():
    stack = Stack()
    
    while True:
        action = input("Enter 'push', 'pop', 'peek', 'is_empty', or 'exit': ").strip().lower()
        
        if action == 'push':
            item = input("Enter an item to push: ")
            stack.push(item)
            print(f"Pushed: {item}")

        elif action == 'pop':
            try:
                popped_item = stack.pop()
                print(f"Popped: {popped_item}")
            except IndexError as e:
                print(e)

        elif action == 'peek':
            try:
                top_item = stack.peek()
                print(f"Top item: {top_item}")
            except IndexError as e:
                print(e)

        elif action == 'is_empty':
            print(f"Is the stack empty? {stack.is_empty()}")

        elif action == 'exit':
            print("Exiting...")
            break

