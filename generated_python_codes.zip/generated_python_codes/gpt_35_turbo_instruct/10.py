Sure, here is a possible solution:

# define a function for creating the stack
def create_stack():
    stack = []
    return stack

# define functions for pushing and popping elements from the stack
def push(stack, element):
    stack.append(element)

def pop(stack):
    if not is_empty(stack):
        return stack.pop()
    else:
        return 'Stack is empty'

# define function for peeking at the top element of the stack
def peek(stack):
    if not is_empty(stack):
        return stack[-1]
    else:
        return 'Stack is empty'

# define function for checking if the stack is empty
def is_empty(stack):
    return len(stack) == 0

# define a small main section for example input/output handling
def main():
    stack = create_stack()
    push(stack, 1)
    push(stack, 2)
    push(stack, 3)

    print('Stack:', stack)
    print('Peeking at the top element:', peek(stack))
    print('Popping the top element:', pop(stack))
    print('Stack after popping:', stack)
    print('Is the stack empty?', is_empty(stack))

if __name__ == '__main__':
    main()
