Here is a clean Python solution for this programming assignment:

def reverse_words(sentence):
    """
    Reverses words in a sentence without changing character order inside each word.
    """
    words = sentence.split(' ')
    reversed_words = [word[::-1] for word in words]
    return ' '.join(reversed_words)

def main():
    example_input = 'Hello world'
    example_output = reverse_words(example_input)
    print(example_output)

if __name__ == '__main__':
    main()
