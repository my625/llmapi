import sys

OPS = {"+": (1, "L"), "-": (1, "L"), "*": (2, "L"), "/": (2, "L"), "^": (3, "R")}

def tokenize(expr: str):
    expr = expr.strip()
    if not expr:
        return [], True
    if any(c.isspace() for c in expr):
        toks = expr.split()
        compact = all(len(t) == 1 for t in toks)
        return toks, compact
    toks, i, n = [], 0, len(expr)
    while i < n:
        c = expr[i]
        if c.isdigit():
            j = i + 1
            while j < n and expr[j].isdigit():
                j += 1
            toks.append(expr[i:j]); i = j
        elif c.isalpha() or c == "_":
            j = i + 1
            while j < n and (expr[j].isalnum() or expr[j] == "_"):
                j += 1
            toks.append(expr[i:j]); i = j
        else:
            toks.append(c); i += 1
    return toks, True

def infix_to_postfix(tokens):
    out, st = [], []
    for t in tokens:
        if t in OPS:
            p, a = OPS[t]
            while st and st[-1] in OPS:
                p2, a2 = OPS[st[-1]]
                if (a == "L" and p2 >= p) or (a == "R" and p2 > p):
                    out.append(st.pop())
                else:
                    break
            st.append(t)
        elif t == "(":
            st.append(t)
        elif t == ")":
            while st and st[-1] != "(":
                out.append(st.pop())
            if st and st[-1] == "(":
                st.pop()
        else:
            out.append(t)
    while st:
        op = st.pop()
        if op not in ("(", ")"):
            out.append(op)
    return out

def main():
    data = sys.stdin.read()
    expr = data.strip() if data.strip() else "a+b*(c-d)^
