Sure, here's a solution:

from collections import OrderedDict

class LRUCache:

    def __init__(self, capacity):
        self.cache = OrderedDict()
        self.capacity = capacity

    def get(self, key):
        if key not in self.cache:
            return -1
        self.cache.move_to_end(key)
        return self.cache[key]

    def put(self, key, value):
        if key in self.cache:
            self.cache.move_to_end(key)
        self.cache[key] = value
        if len(self.cache) > self.capacity:
            self.cache.popitem(last=False)

def main():
    cache = LRUCache(2)
    cache.put(1, 'a')
    cache.put(2, 'b')
    print(cache.get(1))
    cache.put(3, 'c')
    print(cache.get(2))
    cache.put(4, 'd')
    print(cache.get(1))
    print(cache.get(3))
    print(cache.get(4))

if __name__ == '__main__':
    main()
