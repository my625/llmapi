Sure, here you go:

def quick_sort(arr):
    if len(arr) <= 1:
        return arr
    pivot = arr[0]
    less_than_pivot = [x for x in arr[1:] if x < pivot]
    greater_than_pivot = [x for x in arr[1:] if x >= pivot]
    return quick_sort(less_than_pivot) + [pivot] + quick_sort(greater_than_pivot)

if __name__ == '__main__':
    input_arr = [5, 9, 1, 8, 3, 2, 6]
    print('Input array:', input_arr)
    sorted_arr = quick_sort(input_arr)
    print('Sorted array:', sorted_arr)

Output:
Input array: [5, 9, 1, 8, 3, 2, 6]
Sorted array: [1, 2, 3, 5, 6, 8, 9]
