Here is a clean Python solution for implementing binary search recursively and iteratively:

def binary_search_recursively(lst, target):
    """Recursive implementation of binary search"""
    if len(lst) == 0:
        return False
    else:
        mid = len(lst) // 2
        if lst[mid] == target:
            return True
        elif lst[mid] > target:
            return binary_search_recursively(lst[:mid], target)
        else:
            return binary_search_recursively(lst[mid + 1:], target)

def binary_search_iteratively(lst, target):
    """Iterative implementation of binary search"""
    start = 0
    end = len(lst) - 1
    while start <= end:
        mid = (start + end) // 2
        if lst[mid] == target:
            return True
        elif lst[mid] < target:
            start = mid + 1
        else:
            end = mid - 1
    return False

def main():
    """Example input/output handling"""
    lst = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    target = 5
    print("Recursive binary search:")
    print(binary_search_recursively(lst, target))
    print("Iterative binary search:")
    print(binary_search_iteratively(lst, target))

if __name__ == '__main__':
    main()
