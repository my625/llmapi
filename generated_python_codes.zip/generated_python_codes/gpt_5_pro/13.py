import sys

PAIRS = {")": "(", "]": "[", "}": "{"}
OPEN = set(PAIRS.values())


def is_balanced(s: str) -> bool:
    stack
