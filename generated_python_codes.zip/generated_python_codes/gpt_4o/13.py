def is_balanced(expression):
    stack = []
    bracket_map = {')': '(', ']': '[', '}': '{'}

    for char in expression:
        if char in bracket_map.values():
            stack.append(char)
        elif char in bracket_map.keys():
            if stack and stack[-1] == bracket_map[char]:
                stack.pop()
            else:
                return False
    return not stack

def main():
    test_cases = [
        "([]){}",     # balanced
        "([)]",       # not balanced
        "((()))",     # balanced
        "({[()]})",   # balanced
        "({[})",      # not balanced
        "",           # balanced
        "([{}])"      # balanced
    ]
    
    for expression in test_cases:
        if is_balanced(expression):
            print(f"{expression}: Balanced")
        else:
            print(f"{expression}: Not Balanced")

if __name__ == "__main__":
    main()
