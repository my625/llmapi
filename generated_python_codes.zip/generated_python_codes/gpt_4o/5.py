def count_char_frequency(s):
    freq_dict = {}

    # Count frequency of each character
    for char in s:
        if char in freq_dict:
            freq_dict[char] += 1
        else:
            freq_dict[char] = 1

    # Sort the dictionary by frequency, then by character
    sorted_freq = sorted(freq_dict.items(), key=lambda x: (-x[1], x[0]))

    # Print the sorted frequencies
    for char, freq in sorted_freq:
        print(f"{char}: {freq}")

def main():
    # Example input
    example_string = "example string for frequency counting"
    print(f"Input: {example_string}")
    print("Character Frequencies:")
    count_char_frequency(example_string)

if __name__ == "__main__":
    main()
