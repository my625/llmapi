from collections import deque, defaultdict

class Graph:
    def __init__(self):
        self.adjacency_list = defaultdict(list)

    def add_edge(self, u, v):
        self.adjacency_list[u].append(v)
        self.adjacency_list[v].append(u)  # Assuming undirected graph

    def bfs(self, start_vertex):
        visited = set()
        queue = deque([start_vertex])
        traversal_order = []

        while queue:
            vertex = queue.popleft()
            if vertex not in visited:
                visited.add(vertex)
                traversal_order.append(vertex)
                for neighbor in self.adjacency_list[vertex]:
                    if neighbor not in visited:
                        queue.append(neighbor)
        return traversal_order

def main():
    graph = Graph()
    edges = [(0, 1), (0, 2), (1, 2), (2, 0), (2, 3), (3, 3)]
    
    for u, v in edges:
        graph.add_edge(u, v)

    start_vertex = 2
    result = graph.bfs(start_vertex)
    print("BFS Traversal starting from vertex", start_vertex, ":", result)

if __name__ == "__main__":
    main()
