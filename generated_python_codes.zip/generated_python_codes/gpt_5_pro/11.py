from collections import deque
import sys


class Queue:
    def __init__(self):
        self._dq = deque()

    def enqueue(self, item):
        self._dq.append(item)

    def dequeue(self):
        if not self._dq:
            raise IndexError("dequeue from empty queue")
        return self._dq.popleft()

    def try_dequeue(self, default=None):
        return self._dq.popleft() if self._dq else default

    def is_empty(self):
        return not self._dq

    def __len__(self):
        return len(self._dq)


def run_commands(lines):
    q = Queue()
    out = []
    for line in lines:
        parts = line.strip().split()
        if not parts:
            continue
        cmd = parts[0].lower()
        if cmd in ("enq", "enqueue", "push"):
            if len(parts) < 2:
                continue
            q.enqueue(" ".join(parts[1:]))
        elif cmd in ("deq", "dequeue", "pop"):
            out.append(q.try_dequeue("EMPTY"))
    return out


def main():
    data = sys.stdin.read().splitlines()
    if not data:
        data = ["ENQ 10", "ENQ 20", "DEQ", "DEQ", "DEQ"]

    try:
        n = int(data[0].strip())
        lines = data[1:1 + n]
    except Exception:
        lines = data

    sys.stdout.write("\n".join(run_commands(lines)))


if __name__ == "__main__":
    main()
