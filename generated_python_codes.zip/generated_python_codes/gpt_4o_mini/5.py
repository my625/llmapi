def count_character_frequency(s):
    frequency = {}
    for char in s:
        if char.isalpha():  # Count only alphabetic characters
            char = char.lower()  # Normalize to lowercase
            frequency[char] = frequency.get(char, 0) + 1
    return frequency

def sort_frequency(frequency):
    # Sort by frequency (descending) and then by character (ascending)
    return sorted(frequency.items(), key=lambda item: (-item[1], item[0]))

def print_frequency(sorted_freq):
    for char, count in sorted_freq:
        print(f"{char}: {count}")

def main():
    input_string = input("Enter a string: ")
    frequency = count_character_frequency(input_string)
    sorted_freq = sort_frequency(frequency)
    print_frequency(sorted_freq)

if __name__ == "__main__":
    main()
