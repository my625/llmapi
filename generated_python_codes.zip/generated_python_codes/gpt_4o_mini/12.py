def evaluate_postfix(expression):
    stack = []
    operators = {'+', '-', '*', '/'}

    for token in expression.split():
        if token not in operators:
            stack.append(float(token))
        else:
            b = stack.pop()
            a = stack.pop()
            if token == '+':
                stack.append(a + b)
            elif token == '-':
                stack.append(a - b)
            elif token == '*':
                stack.append(a * b)
            elif token == '/':
                if b == 0:
                    raise ZeroDivisionError("Division by zero is not allowed")
                stack.append(a / b)

    if len(stack) != 1:
        raise ValueError("Invalid postfix expression")
    
    return stack[0]

def main():
    while True:
        expression = input("Enter a postfix expression (or 'quit' to exit): ")
        if expression.lower() == 'quit':
            break
        try:
            result = evaluate_postfix(expression)
            print(f"Result: {result}")
        except Exception as e:
            print(f"Error: {e}")

if __name__ == "__main__":
    main()
