from collections import deque

class Queue:
    def __init__(self):
        self.items = deque()
    
    def is_empty(self):
        return len(self.items) == 0
    
    def size(self):
        return len(self.items)
    
    def enqueue(self, item):
        self.items.append(item)
    
    def dequeue(self):
        if self.is_empty():
            raise IndexError("Dequeue from an empty queue")
        return self.items.popleft()
    
    def peek(self):
        if self.is_empty():
            raise IndexError("Peek from an empty queue")
        return self.items[0]
    
    def __str__(self):
        return str(self.items)

def main():
    queue = Queue()
    
    while True:
        print("\nQueue Operations:")
        print("1. Enqueue")
        print("2. Dequeue")
        print("3. Peek")
        print("4. Check if empty")
        print("5. Size")
        print("6. Exit")
        
        choice = input("Enter your choice (1-6): ")
        
        if choice == '1':
            item = input("Enter item to enqueue: ")
            queue.enqueue(item)
            print(f"Enqueued: {item}")
        
        elif choice == '2':
            try:
                item = queue.dequeue()
                print(f"Dequeued: {item}")
            except IndexError as e:
                print(e)
        
        elif choice == '3':
            try:
                item = queue.peek()
                print(f"Front item: {item}")
            except IndexError as e:
                print(e)
