import sys
from collections import deque

DIRS = [(-1, 0, 'U'), (1, 0, 'D'), (0, -1, 'L'), (0, 1, 'R')]

def solve(lines):
    n, m = map(int, lines[0].split())
    g = [list(lines[i + 1].rstrip('\n')) for i in range(n)]
    sr = sc = tr = tc = -1
    for r in range(n):
        for c in range(m):
            if g[r][c] == 'S':
                sr, sc = r, c
            elif g[r][c] == 'E':
                tr, tc = r, c

    dist = [[-1] * m for _ in range(n)]
    prev = [[None] * m for _ in range(n)]  # (pr, pc, move_char)
    q = deque([(sr, sc)])
    dist[sr][sc] = 0

    while q:
        r, c = q.popleft()
        if (r, c) == (tr, tc):
            break
        for dr, dc, ch in DIRS:
            nr, nc = r + dr, c + dc
            if 0 <= nr < n and 0 <= nc < m and dist[nr][nc] == -1 and g[nr][nc] != '#':
                dist[nr][nc] = dist[r][c] + 1
                prev[nr][nc] = (r, c, ch)
                q.append((nr, nc))

    if dist[tr][tc] == -1:
        return "-1\n"
    path = []
    r, c = tr, tc
    while (r, c) != (sr, sc):
        pr, pc, ch = prev[r][c]
        path.append(ch)
        r, c = pr, pc
    path.reverse()
    return f"{dist[tr][tc]}\n{''.join(path)}\n"

def main():
    data = sys.stdin.read().splitlines()
    if not data:
        data = [
            "5 7",
            "S..#...",
            ".##.#..",
            "...#..E",
            ".#.....",
            "...##..",
        ]
    sys.stdout.write(solve(data))

if __name__ == "__main__":
    main()
