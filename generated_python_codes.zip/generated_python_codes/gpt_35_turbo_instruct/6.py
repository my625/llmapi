Sure, here's a clean Python solution that implements recursive and iterative factorial with comparison:

import math

def recursive_factorial(n):
    if n == 0:
        return 1
    else:
        return n * recursive_factorial(n-1)

def iterative_factorial(n):
    result = 1
    for i in range(1, n+1):
        result *= i
    return result

def compare_factorial(n):
    recursive_result = recursive_factorial(n)
    iterative_result = iterative_factorial(n)
    if recursive_result == iterative_result:
        print('Recursive and iterative factorial are equal!')
    else:
        print('Recursive and iterative factorial are not equal!')

# Example input/output handling:
print('Recursive factorial of 5:', recursive_factorial(5))
print('Iterative factorial of 5:', iterative_factorial(5))
compare_factorial(5)

# Output:
Recursive factorial of 5: 120
Iterative factorial of 5: 120
Recursive and iterative factorial are equal!
