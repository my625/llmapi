class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class SinglyLinkedList:
    def __init__(self):
        self.head = None

    def insert(self, data):
        new_node = Node(data)
        if not self.head:
            self.head = new_node
        else:
            current = self.head
            while current.next:
                current = current.next
            current.next = new_node

    def delete(self, key):
        current = self.head
        previous = None
        while current and current.data != key:
            previous = current
            current = current.next
        if not current:
            return  # Key not found
        if not previous:
            self.head = current.next
        else:
            previous.next = current.next

    def display(self):
        current = self.head
        elements = []
        while current:
            elements.append(current.data)
            current = current.next
        return elements

def main():
    sll = SinglyLinkedList()
    sll.insert(1)
    sll.insert(2)
    sll.insert(3)
    print("List after inserts:", sll.display())  # [1, 2, 3]
    sll.delete(2)
    print("List after deletion:", sll.display())  # [1, 3]
    sll.delete(1)
    print("List after deletion:", sll.display())  # [3]

if __name__ == "__main__":
    main()
