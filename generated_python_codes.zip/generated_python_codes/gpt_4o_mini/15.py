class ListNode:
    def __init__(self, value=0, next=None):
        self.value = value
        self.next = next

def has_cycle(head):
    slow = head
    fast = head
    
    while fast and fast.next:
        slow = slow.next        # Move slow pointer by 1
        fast = fast.next.next   # Move fast pointer by 2
        
        if slow == fast:        # Cycle detected
            return True
            
    return False               # No cycle

def main():
    # Creating a linked list with a cycle for testing
    node1 = ListNode(1)
    node2 = ListNode(2)
    node3 = ListNode(3)
    node4 = ListNode(4)
    
    node1.next = node2
    node2.next = node3
    node3.next = node4
    node4.next = node2  # Creating a cycle here
    
    # Test for cycle
    if has_cycle(node1):
        print("Cycle detected")
    else:
        print("No cycle detected")
    
    # Creating a linked list without a cycle
    node5 = ListNode(5)
    node6 = ListNode(6)
    
    node5.next = node6  # No cycle
    
    # Test for cycle
    if has_cycle(node5):
        print("Cycle detected")
    else:
        print("No cycle detected")

if __name__ == "__main__":
    main()
