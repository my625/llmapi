import sys


def longest_palindromic_substring(s: str) -> str:
    n = len(s)
    if n <
