import sys


def binary_search_iter(a, x):
    lo, hi = 0, len(a) - 1
    while lo <= hi:
        mid = (lo + hi) // 2
        v = a[mid]
        if v == x:
            return mid
        if v < x:
            lo = mid + 1
        else:
            hi = mid - 1
    return -1


def binary_search_rec(a, x, lo=0, hi=None):
    if hi is None:
        hi = len(a) - 1
    if lo > hi:
        return -1
    mid = (lo + hi) // 2
    v = a[mid]
    if v == x:
        return mid
    if v < x:
        return binary_search_rec(a, x, mid + 1, hi)
    return binary_search_rec(a, x, lo, mid - 1)


def _parse_input(text):
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    if len(lines) >= 2:
        a = list(map(int, lines[0].split()))
        x = int(lines[1])
        return a, x
    return [1, 3, 4, 7, 9, 12, 15], 7  # default example


def main():
    a, x = _parse_input(sys.stdin.read())
    i1 = binary_search_iter(a, x)
    i2 = binary_search_rec(a, x)
    sys.stdout.write(f"iter={i1}\nrec={i2}\n")


if __name__ == "__main__":
    main()
