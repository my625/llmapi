class ListNode:
    def __init__(self, value=0, next=None):
        self.value = value
        self.next = next

def has_cycle(head):
    if not head or not head.next:
        return False

    slow = head
    fast = head.next

    while slow != fast:
        if not fast or not fast.next:
            return False
        slow = slow.next
        fast = fast.next.next

    return True

def create_linked_list(values, pos):
    if not values:
        return None

    head = ListNode(values[0])
    current = head
    cycle_node = None

    for i in range(1, len(values)):
        current.next = ListNode(values[i])
        current = current.next
        if i == pos:
            cycle_node = current

    if pos != -1:
        current.next = cycle_node

    return head

def main():
    # Example 1: List with a cycle
    values = [3, 2, 0, -4]
    pos = 1  # Cycle at index 1
    head = create_linked_list(values, pos)
    print(has_cycle(head))  # Output: True

    # Example 2: List without a cycle
    values = [1, 2]
    pos = -1  # No cycle
    head = create_linked_list(values, pos)
    print(has_cycle(head))  # Output: False

    # Example 3: Empty list
    values = []
    pos = -1  # No cycle
    head = create_linked_list(values, pos)
    print(has_cycle(head))  # Output: False

if __name__ == "__main__":
    main()
