import sys
from collections import Counter


def read_text() -> str:
    data = sys.stdin.read()
    if data:
        if data.endswith("\n"):
            data = data[:-1]
        return data
    if sys.stdin.isatty():
        return "banana"
    return ""


def count_chars(text: str) -> Counter:
    return Counter(text)


def sorted_freq_items(freq: Counter):
    # Sort by frequency (desc), then by character (asc)
    return sorted(freq.items(), key=lambda kv: (-kv[1], kv[0]))


def format_lines(items) -> str:
    out = []
    for ch, n in items:
        out.append(f"{ch} {n}")
    return "\n".join(out)


def main() -> None:
    text = read_text()
    freq = count_chars(text)
    items = sorted_freq_items(freq)
    sys.stdout.write(format_lines(items))
    if items:
        sys.stdout.write("\n")


if __name__ == "__main__":
    main()
