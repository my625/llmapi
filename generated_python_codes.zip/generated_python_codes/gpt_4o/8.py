def tower_of_hanoi(n, source, target, auxiliary):
    if n == 1:
        print(f"Move disk 1 from {source} to {target}")
        return
    tower_of_hanoi(n-1, source, auxiliary, target)
    print(f"Move disk {n} from {source} to {target}")
    tower_of_hanoi(n-1, auxiliary, target, source)

def main():
    n = 3  # Number of disks
    tower_of_hanoi(n, 'A', 'C', 'B')  # A, B and C are names of rods

if __name__ == "__main__":
    main()
