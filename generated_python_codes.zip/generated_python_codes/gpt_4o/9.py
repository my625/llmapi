def binary_search_recursive(arr, target, low, high):
    if low > high:
        return -1
    mid = (low + high) // 2
    if arr[mid] == target:
        return mid
    elif arr[mid] > target:
        return binary_search_recursive(arr, target, low, mid - 1)
    else:
        return binary_search_recursive(arr, target, mid + 1, high)

def binary_search_iterative(arr, target):
    low, high = 0, len(arr) - 1
    while low <= high:
        mid = (low + high) // 2
        if arr[mid] == target:
            return mid
        elif arr[mid] < target:
            low = mid + 1
        else:
            high = mid - 1
    return -1

def main():
    arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    target = 7
    print("Recursive binary search:")
    result_recursive = binary_search_recursive(arr, target, 0, len(arr) - 1)
    if result_recursive != -1:
        print(f"Element found at index {result_recursive}")
    else:
        print("Element not found")

    print("Iterative binary search:")
    result_iterative = binary_search_iterative(arr, target)
    if result_iterative != -1:
        print(f"Element found at index {result_iterative}")
    else:
        print("Element not found")

if __name__ == "__main__":
    main()
